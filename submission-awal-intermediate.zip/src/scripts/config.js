const CONFIG = {
  ACCESS_TOKEN_KEY : 'token',
  BASE_URL : 'https://story-api.dicoding.dev/v1',
  MAP_SERVICES_API_KEY : 'x5un63dC5MBkB55HUz6F',
};

export default CONFIG;
